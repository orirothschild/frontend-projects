export const regionStyle = {
  border: '1px solid red',
  marginTop: 10,
  padding: 10,
};

export const errorStyle = {
  color: 'red',
  marginTop: 10,
  padding: 10,
};
