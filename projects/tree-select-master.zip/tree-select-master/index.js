// export this package's api
import TreeSelect from './src';

export default TreeSelect;

export { TreeNode, SHOW_ALL, SHOW_PARENT, SHOW_CHILD } from './src';
