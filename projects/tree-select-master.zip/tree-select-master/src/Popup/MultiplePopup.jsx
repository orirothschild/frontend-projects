import BasePopup from '../Base/BasePopup';

export default BasePopup;
