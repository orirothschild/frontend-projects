# Jammming

A Codecademy project to create a playlist creator for Spotify.