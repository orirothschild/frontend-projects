const todos = [
  {
    id: 1,
    text: 'Do a very important task',
    completion: false
  },
  {
    id: 2,
    text: 'Team meeting at 11 am',
    completion: false
  },
  {
    id: 3,
    text: 'Learn React JS',
    completion: false
  }
];

export default todos;