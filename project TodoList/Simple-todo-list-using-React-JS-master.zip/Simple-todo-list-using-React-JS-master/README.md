# Simple Todo List Using React JS

### Full Application
![screen shot 2017-12-15 at 4 50 04 pm](https://user-images.githubusercontent.com/17401118/34038902-0babafca-e1b8-11e7-949b-e0dfba8e6eb6.jpg)

### Todo List
![screenshot-localhost-3000-2017-12-15-16-39-11-925](https://user-images.githubusercontent.com/17401118/34038904-0c1e9580-e1b8-11e7-8c46-de1076f2f3e2.png)

### Create New Todo
![screenshot-localhost-3000-2017-12-15-16-39-57-019](https://user-images.githubusercontent.com/17401118/34038905-0c583768-e1b8-11e7-96d2-dc30a7d36466.png)

### Update Todo
![screenshot-localhost-3000-2017-12-15-16-40-21-162](https://user-images.githubusercontent.com/17401118/34038906-0c9437f4-e1b8-11e7-8a53-8393cd464135.png)

**Note:** *This a practice project. Don't try to use any commercial purpose*
